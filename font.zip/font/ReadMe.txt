About Zoink Fat
*************

Zoink Fat is a font I did years ago, based on an old Mac font called GilbertShelton. When I first started doing design (many years ago when the Mac Plus was the top of the line), there was a font available called GilbertShelton, but it was only available in bitmap format. Basically, I did my best to create an outline font from the largest available screen font. 

The name is a nod to the fight scenes on the old Batman TV series (and to Shaggy on Scooby Doo...).

Freeware. This is all there is.

FREEWARE NOTICE
Zoink Fat is freeware. It is my hope that you will like this font and want to check out my other fonts. Feel free to check them out at my humble website, located at:


http:/members.aol.com/typea002/


Any comments or questions can be emailed to:

Marty Yawnick
TypeA002@aol.com
typea@flash.net



-----------------------------------------------------------------------------
COPYRIGHT NOTICE
The data contained in these files is Copyright �1992, 1998 Marty Yawnick. All rights reserved.

This version of Zoink Fat may be freely distibuted to your friends for evaluation, uploaded to other BBSs, or linked or attached to Web pages as long as it is not altered and as long as this ReadMe file accompanies the font. This font may NOT be distributed by commercial shareware distributors, those putting together floppy disk shareware compilations or the huge CD-ROM shareware collections. If you are interested in any form of mass distribution of this font, please contact me first by email or snail mail.

CONTACTING ME
You can reach me at the above mailing address, Internet at typea@flash.net, or on America Online at TypeA002 (that would be zero-zero-two).

I hope you like it. Let me know!

Once again, thanks!

revised 3/98